package com.project.entities;

public class ChangePassword {
    
	private String newPassword;
//	private String 
}
