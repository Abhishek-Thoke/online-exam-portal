package com.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.entities.Apply_job;

public interface Apply_Job_Repo extends JpaRepository<Apply_job, Long>{
     
}
