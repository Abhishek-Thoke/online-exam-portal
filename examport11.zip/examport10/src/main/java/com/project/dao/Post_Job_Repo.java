package com.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.entities.Post_Job;

public interface Post_Job_Repo extends JpaRepository<Post_Job, Long>{

}
