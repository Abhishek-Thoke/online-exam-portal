function Appliedjob()
{


    return(<>
    <h1>Applied Job Page</h1>
    </>);
}
export default Appliedjob;