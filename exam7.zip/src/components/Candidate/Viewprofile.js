function Viewprofile()
{


    return(<>
    <h1>Viewprofile Job Page</h1>
    </>);
}
export default Viewprofile;