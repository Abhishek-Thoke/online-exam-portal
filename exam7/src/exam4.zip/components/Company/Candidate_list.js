function Candidate_list()
{


    return(<>
    <h1>This is Candidate_list Page</h1>
    </>);
}
export default Candidate_list;