

function Conduct_exam()
{


    return(<>
    <h1>This is Conduct_exam Page</h1>
    </>);
}
export default Conduct_exam;