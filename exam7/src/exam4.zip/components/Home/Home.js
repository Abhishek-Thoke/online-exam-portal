import Footer from "./Footer";
import Header from "./Header";
import '../../../node_modules/bootstrap/dist/css/bootstrap.css'

function Home()
{

    return(
    <>
    <Header></Header>
    
<div>
    
</div>
    <Footer></Footer>
    </>

    );
}
export default Home;