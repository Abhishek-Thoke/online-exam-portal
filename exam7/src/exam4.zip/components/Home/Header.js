import '../../../node_modules/bootstrap/dist/css/bootstrap.css'
import {Link,useNavigate} from "react-router-dom";

import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css'
import '../../assets/divs.css'
function Header()
{

    return(
    <>
      <Navbar bg="info">
        <Container>
          <Navbar.Brand href="/company/addjob">Addjob</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/company">Home</Nav.Link>
            <Nav.Link href="/company/setquestions">Set Questions</Nav.Link>
            <Nav.Link href="/company/candidate_list">Candidate List</Nav.Link>
          </Nav>
          <button className='btn btn-outline-success'>Edit</button><div className='space'></div>
          <button className='btn btn-outline-danger'>Logout</button>
        </Container>
      </Navbar>
    </>

    );
}
export default Header;