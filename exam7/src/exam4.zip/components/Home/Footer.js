import '../../../node_modules/bootstrap/dist/css/bootstrap.css'
function Footer()
{

    return(
    <>
    <div className="footdiv">
    <h6>made by Ganesh Shinde</h6>
    </div>
    
    </>

    );
}
export default Footer;