function Appliedjob()
{


    return(<>
    <h1>This is Candidate_list Page</h1>
    </>);
}
export default Appliedjob;